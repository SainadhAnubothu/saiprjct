package com.cg.employeemaintenancesystem.beans;

import java.sql.Date;
import java.time.LocalDate;

public class EmployeeDetails {
	private String empId;
	private String empFirstName;
	private String empLastName;
	private String department;
	private String Grade;
	private String maritalStatus;
	private String employeeType;
	private String empDesignation;
	private LocalDate fromDate;
	private LocalDate toDate;
private int diff;
private String status;


	public int getDiff() {
	return diff;
}

public void setDiff(int diff) {
	this.diff = diff;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

	public LocalDate getFromDate() {
		return fromDate;
	}

	public void setFromDate(LocalDate ld) {
		this.fromDate = ld;
	}

	public LocalDate getToDate() {
		return toDate;
	}

	public void setToDate(LocalDate ld1) {
		this.toDate = ld1;
	}

	public String getEmpDesignation() {
		return empDesignation;
	}

	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpFirstName() {
		return empFirstName;
	}

	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}

	public String getEmpLastName() {
		return empLastName;
	}

	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getGrade() {
		return Grade;
	}

	public void setGrade(String grade) {
		Grade = grade;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

}
