package com.cg.employeemaintenancesystem.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.employeemaintenancesystem.beans.EmployeeDetails;
import com.cg.employeemaintenancesystem.exception.EmployeeMaintenanceException;

public interface IEmployeeDao {
	public EmployeeDetails idSearch(String id) throws SQLException, EmployeeMaintenanceException;
	public ArrayList<EmployeeDetails> firstNameSearch(String firstName) throws SQLException, EmployeeMaintenanceException;
	public ArrayList<EmployeeDetails> lastNameSearch(String lastName) throws SQLException, EmployeeMaintenanceException;
	public ArrayList<EmployeeDetails> deptSearch(String department) throws SQLException, EmployeeMaintenanceException;
	public ArrayList<EmployeeDetails> gradeSearch(String grade)throws SQLException, EmployeeMaintenanceException;
	public ArrayList<EmployeeDetails> maritalStatusSearch(String maritalStatus)throws SQLException, EmployeeMaintenanceException;
	public int insertLeaveDetails(EmployeeDetails ed) throws SQLException, EmployeeMaintenanceException;
}
