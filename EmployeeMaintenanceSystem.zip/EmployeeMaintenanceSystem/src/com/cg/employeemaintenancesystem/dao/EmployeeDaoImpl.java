package com.cg.employeemaintenancesystem.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.employeemaintenancesystem.beans.EmployeeDetails;
import com.cg.employeemaintenancesystem.exception.EmployeeMaintenanceException;
import com.cg.employeemaintenancesystem.util.DBConnection;

public class EmployeeDaoImpl implements IEmployeeDao{
public Connection conn;
DBConnection dbconn=new DBConnection();
PreparedStatement pst;
	@Override
	public EmployeeDetails idSearch(String id) throws SQLException, EmployeeMaintenanceException {
		conn=dbconn.getConnection();
		pst=conn.prepareStatement("SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,DEPT_NAME,EMP_GRADE,EMP_DESIGNATION FROM EMPLOYEE JOIN Department ON EMPLOYEE.EMP_DEPT_ID=DEPARTMENT.DEPT_ID WHERE EMP_ID=?");
		pst.setString(1, id);
		ResultSet rs=pst.executeQuery();
		EmployeeDetails ed=new EmployeeDetails();
		while(rs.next()){
			ed.setEmpId(rs.getString(1));
			ed.setEmpFirstName(rs.getString(2));
			ed.setEmpLastName(rs.getString(3));
			ed.setDepartment(rs.getString(4));
			ed.setGrade(rs.getString(5));
			ed.setEmpDesignation(rs.getString(6));
		}
		return ed;
	}

	@Override
	public ArrayList<EmployeeDetails> firstNameSearch(String firstName) throws SQLException, EmployeeMaintenanceException {
		conn=dbconn.getConnection();
		pst=conn.prepareStatement("SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,DEPT_NAME,EMP_GRADE,EMP_DESIGNATION FROM EMPLOYEE JOIN Department ON EMPLOYEE.EMP_DEPT_ID=DEPARTMENT.DEPT_ID WHERE EMP_FIRST_NAME=?");
		pst.setString(1, firstName);
		ResultSet rs=pst.executeQuery();
		ArrayList<EmployeeDetails> list=new ArrayList<>();
		while(rs.next()){
			EmployeeDetails ed=new EmployeeDetails();
			ed.setEmpId(rs.getString(1));
			ed.setEmpFirstName(rs.getString(2));
			ed.setEmpLastName(rs.getString(3));
			ed.setDepartment(rs.getString(4));
			ed.setGrade(rs.getString(5));
			ed.setEmpDesignation(rs.getString(6));
			list.add(ed);
		}
		return list;
	}

	@Override
	public ArrayList<EmployeeDetails> lastNameSearch(String lastName) throws SQLException, EmployeeMaintenanceException {
		conn=dbconn.getConnection();
		pst=conn.prepareStatement("SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,DEPT_NAME,EMP_GRADE,EMP_DESIGNATION FROM EMPLOYEE JOIN Department ON EMPLOYEE.EMP_DEPT_ID=DEPARTMENT.DEPT_ID WHERE EMP_LAST_NAME=?");
		pst.setString(1, lastName);
		ResultSet rs=pst.executeQuery();
		ArrayList<EmployeeDetails> list=new ArrayList<>();
		while(rs.next()){
			EmployeeDetails ed=new EmployeeDetails();
			ed.setEmpId(rs.getString(1));
			ed.setEmpFirstName(rs.getString(2));
			ed.setEmpLastName(rs.getString(3));
			ed.setDepartment(rs.getString(4));
			ed.setGrade(rs.getString(5));
			ed.setEmpDesignation(rs.getString(6));
			list.add(ed);
		}
		return list;
		
	}

	@Override
	public ArrayList<EmployeeDetails> deptSearch(String department) throws SQLException, EmployeeMaintenanceException {
		conn=dbconn.getConnection();
		pst=conn.prepareStatement("SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,DEPT_NAME,EMP_GRADE,EMP_DESIGNATION FROM EMPLOYEE JOIN Department ON EMPLOYEE.EMP_DEPT_ID=DEPARTMENT.DEPT_ID WHERE DEPT_NAME=?");
		pst.setString(1, department);
		ResultSet rs=pst.executeQuery();
		ArrayList<EmployeeDetails> list=new ArrayList<>();
		while(rs.next()){
			EmployeeDetails ed=new EmployeeDetails();
			ed.setEmpId(rs.getString(1));
			ed.setEmpFirstName(rs.getString(2));
			ed.setEmpLastName(rs.getString(3));
			ed.setDepartment(rs.getString(4));
			ed.setGrade(rs.getString(5));
			ed.setEmpDesignation(rs.getString(6));
			list.add(ed);
		}
		return list;
		
	}

	@Override
	public ArrayList<EmployeeDetails> gradeSearch(String grade) throws SQLException, EmployeeMaintenanceException {
		conn=dbconn.getConnection();
		pst=conn.prepareStatement("SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,DEPT_NAME,EMP_GRADE,EMP_DESIGNATION FROM EMPLOYEE JOIN Department ON EMPLOYEE.EMP_DEPT_ID=DEPARTMENT.DEPT_ID WHERE EMP_GRADE=?");
		pst.setString(1, grade);
		ResultSet rs=pst.executeQuery();
		ArrayList<EmployeeDetails> list=new ArrayList<>();
		while(rs.next()){
			EmployeeDetails ed=new EmployeeDetails();
			ed.setEmpId(rs.getString(1));
			ed.setEmpFirstName(rs.getString(2));
			ed.setEmpLastName(rs.getString(3));
			ed.setDepartment(rs.getString(4));
			ed.setGrade(rs.getString(5));
			ed.setEmpDesignation(rs.getString(6));
			list.add(ed);
		}
		return list;
	}

	@Override
	public ArrayList<EmployeeDetails> maritalStatusSearch(String maritalStatus) throws SQLException, EmployeeMaintenanceException  {
		conn=dbconn.getConnection();
		pst=conn.prepareStatement("SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,DEPT_NAME,EMP_GRADE,EMP_DESIGNATION FROM EMPLOYEE JOIN Department ON EMPLOYEE.EMP_DEPT_ID=DEPARTMENT.DEPT_ID WHERE EMP_MARITAL_STATUS=?");
		pst.setString(1, maritalStatus);
		ResultSet rs=pst.executeQuery();
		ArrayList<EmployeeDetails> list=new ArrayList<>();
		while(rs.next()){
			EmployeeDetails ed=new EmployeeDetails();
			ed.setEmpId(rs.getString(1));
			ed.setEmpFirstName(rs.getString(2));
			ed.setEmpLastName(rs.getString(3));
			ed.setDepartment(rs.getString(4));
			ed.setGrade(rs.getString(5));
			ed.setEmpDesignation(rs.getString(6));
			list.add(ed);
		}
		return list;
	}

	@Override
	public int insertLeaveDetails(EmployeeDetails ed) throws SQLException, EmployeeMaintenanceException {
		conn=dbconn.getConnection();
		System.out.println(conn);
		pst=conn.prepareStatement("INSERT INTO LEAVE_HISTORY VALUES(seq_leave_id.nextval,?,?,?,?,?,?,default)");
		pst.setString(1,"1006");
		pst.setInt(2,12);
		pst.setInt(3,ed.getDiff());
		pst.setDate(4,Date.valueOf(ed.getFromDate()));
		pst.setDate(5,Date.valueOf(ed.getToDate()));
		pst.setString(6, "applied");
		int val=pst.executeUpdate();
		return val;
	}
}
