package com.cg.employeemaintenancesystem.client;

import java.sql.SQLException;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;


import java.util.Scanner;
import java.time.temporal.ChronoUnit;

import com.cg.employeemaintenancesystem.beans.EmployeeDetails;
import com.cg.employeemaintenancesystem.exception.EmployeeMaintenanceException;
import com.cg.employeemaintenancesystem.service.EmployeeServiceImpl;
import com.cg.employeemaintenancesystem.service.IEmployeeService;

public class Client {

	public static void main(String[] args) {
		try {
			ArrayList<EmployeeDetails> list = new ArrayList<EmployeeDetails>();
			EmployeeDetails ed = new EmployeeDetails();
			Scanner sc = new Scanner(System.in);
			ed.setEmployeeType("user");
			if (ed.getEmployeeType().equalsIgnoreCase("User")) {
				System.out.println("Enter the operation required\n");
				System.out.println("1)Search Details" + "\n"
						+ "2)Apply for Leave");

				int choice = sc.nextInt();
				IEmployeeService si = new EmployeeServiceImpl();
				switch (choice) {
				case 1:
					System.out
							.println("Enter parameter in any one of the fields mentioned below");
					System.out.println("1)Id" + "\n" + "2)First Name" + "\n"
							+ "3)Last Name" + "\n" + "4)Department" + "\n"
							+ "5)Grade" + "\n" + "6)Marital Status");
					int search = sc.nextInt();
					switch (search) {
					case 1:
						System.out.println("Enter the Employee Id");
						String id = sc.next();
						ed = si.idSearch(id);
						System.out.println(ed.getEmpId() + " "
								+ ed.getEmpFirstName() + " "
								+ ed.getEmpLastName() + " "
								+ ed.getDepartment() + " " + ed.getGrade()
								+ " " + ed.getEmpDesignation());
						break;
					case 2:
						System.out.println("Enter the Employee First Name");
						String fname = sc.next();
						list = si.firstNameSearch(fname);
						for (EmployeeDetails employeeDetails : list) {
							System.out.println(employeeDetails.getEmpId() + " "
									+ employeeDetails.getEmpFirstName() + " "
									+ employeeDetails.getEmpLastName() + " "
									+ employeeDetails.getDepartment() + " "
									+ employeeDetails.getGrade() + " "
									+ employeeDetails.getEmpDesignation());
							System.out.println("\n");
						}
						break;
					case 3:
						System.out.println("Enter the Employee Last Name");
						String lname = sc.next();
						list = si.lastNameSearch(lname);
						for (EmployeeDetails employeeDetails : list) {
							System.out.println(employeeDetails.getEmpId() + " "
									+ employeeDetails.getEmpFirstName() + " "
									+ employeeDetails.getEmpLastName() + " "
									+ employeeDetails.getDepartment() + " "
									+ employeeDetails.getGrade() + " "
									+ employeeDetails.getEmpDesignation());
							System.out.println("\n");
						}
						break;
					case 4:
						System.out.println("Enter the Department");
						String dept = sc.next();
						list = si.deptSearch(dept);
						for (EmployeeDetails employeeDetails : list) {
							System.out.println(employeeDetails.getEmpId() + " "
									+ employeeDetails.getEmpFirstName() + " "
									+ employeeDetails.getEmpLastName() + " "
									+ employeeDetails.getDepartment() + " "
									+ employeeDetails.getGrade() + " "
									+ employeeDetails.getEmpDesignation());
							System.out.println("\n");
						}
						break;
					case 5:
						System.out.println("Grade");
						String grade = sc.next();

						list = si.gradeSearch(grade);
						for (EmployeeDetails employeeDetails : list) {
							System.out.println(employeeDetails.getEmpId() + " "
									+ employeeDetails.getEmpFirstName() + " "
									+ employeeDetails.getEmpLastName() + " "
									+ employeeDetails.getDepartment() + " "
									+ employeeDetails.getGrade() + " "
									+ employeeDetails.getEmpDesignation());
							System.out.println("\n");
						}
						break;
					case 6:
						System.out.println("Enter marital status");
						String mStatus = sc.next();
						list = si.maritalStatusSearch(mStatus);
						for (EmployeeDetails employeeDetails : list) {
							System.out.println(employeeDetails.getEmpId() + " "
									+ employeeDetails.getEmpFirstName() + " "
									+ employeeDetails.getEmpLastName() + " "
									+ employeeDetails.getDepartment() + " "
									+ employeeDetails.getGrade() + " "
									+ employeeDetails.getEmpDesignation());
							System.out.println("\n");
						}
						break;
					}
					break;
				case 2:
					System.out
							.println("Enter the date from which you want leave");
					String fd = sc.next();
					DateTimeFormatter dtf = DateTimeFormatter
							.ofPattern("dd/MM/yyyy");
					LocalDate ld = LocalDate.parse(fd, dtf);
					ed.setFromDate(ld);

					System.out
							.println("Enter the date up to which you want leave");
					String td = sc.next();
					LocalDate ld1 = LocalDate.parse(td, dtf);
					ed.setToDate(ld1);
					int diff = (int) ChronoUnit.DAYS.between(ld, ld1);
					ed.setDiff(diff);
					int val=si.insertLeaveDetails(ed);
					if(val==1)
						System.out.println("success");
					else
						System.out.println("failed");
				}
			}
		} catch (SQLException e) {
			System.out.println("null exception from db");
			e.printStackTrace();
		} catch (EmployeeMaintenanceException e) {
			System.out.println("null exception from db");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
